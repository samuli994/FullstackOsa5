import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d99eaa26"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=d99eaa26"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
const Blog = ({
  blog,
  handleLike,
  handleDelete,
  currentUser
}) => {
  _s();
  const [visible, setVisible] = useState(false);
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: visible ? "hide" : "view" }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
        lineNumber: 23,
        columnNumber: 36
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    visible && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { children: blog.url }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
        lineNumber: 26,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        blog.likes,
        " likes ",
        /* @__PURE__ */ jsxDEV("button", { onClick: () => handleLike(blog.id), children: "like" }, void 0, false, {
          fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
          lineNumber: 28,
          columnNumber: 32
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
        lineNumber: 27,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: blog.user && blog.user.name }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
        lineNumber: 30,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDelete(blog.id), children: "delete" }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
        lineNumber: 31,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
      lineNumber: 25,
      columnNumber: 19
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
};
_s(Blog, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JtQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQm5DLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUVoQyxNQUFNQyxPQUFPQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBWUM7QUFBQUEsRUFBY0M7QUFBWSxNQUFNO0FBQUFDLEtBQUE7QUFDaEUsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlSLFNBQVMsS0FBSztBQUU1QyxRQUFNUyxtQkFBbUJBLE1BQU07QUFDN0JELGVBQVcsQ0FBQ0QsT0FBTztBQUFBLEVBQ3JCO0FBRUEsUUFBTUcsWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLEVBQ2hCO0FBRUEsU0FDRSx1QkFBQyxTQUFJLE9BQU9MLFdBQ1Y7QUFBQSwyQkFBQyxTQUNFUjtBQUFBQSxXQUFLYztBQUFBQSxNQUFNO0FBQUEsTUFBRWQsS0FBS2U7QUFBQUEsTUFBTztBQUFBLE1BQUMsdUJBQUMsWUFBTyxTQUFTUixrQkFBbUJGLG9CQUFVLFNBQVMsVUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLFNBRDNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0NBLFdBQ0MsdUJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUdMLGVBQUtnQixPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYTtBQUFBLE1BQ2IsdUJBQUMsT0FDRWhCO0FBQUFBLGFBQUtpQjtBQUFBQSxRQUFNO0FBQUEsUUFBTyx1QkFBQyxZQUFPLFNBQVMsTUFBTWhCLFdBQVdELEtBQUtrQixFQUFFLEdBQUcsb0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQSxXQURyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUdsQixlQUFLbUIsUUFBUW5CLEtBQUttQixLQUFLQyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDO0FBQUEsTUFDaEMsdUJBQUMsWUFBTyxTQUFTLE1BQU1sQixhQUFhRixLQUFLa0IsRUFBRSxHQUFHLHNCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9EO0FBQUEsU0FOdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsT0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBY0E7QUFFSjtBQUFDZCxHQWhDS0wsTUFBSTtBQUFBc0IsS0FBSnRCO0FBa0NOLGVBQWVBO0FBQUksSUFBQXNCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiQmxvZyIsImJsb2ciLCJoYW5kbGVMaWtlIiwiaGFuZGxlRGVsZXRlIiwiY3VycmVudFVzZXIiLCJfcyIsInZpc2libGUiLCJzZXRWaXNpYmxlIiwidG9nZ2xlVmlzaWJpbGl0eSIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwidGl0bGUiLCJhdXRob3IiLCJ1cmwiLCJsaWtlcyIsImlkIiwidXNlciIsIm5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5cclxuY29uc3QgQmxvZyA9ICh7IGJsb2csIGhhbmRsZUxpa2UsIGhhbmRsZURlbGV0ZSwgY3VycmVudFVzZXIgfSkgPT4ge1xyXG4gIGNvbnN0IFt2aXNpYmxlLCBzZXRWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG5cclxuICBjb25zdCB0b2dnbGVWaXNpYmlsaXR5ID0gKCkgPT4ge1xyXG4gICAgc2V0VmlzaWJsZSghdmlzaWJsZSlcclxuICB9XHJcblxyXG4gIGNvbnN0IGJsb2dTdHlsZSA9IHtcclxuICAgIHBhZGRpbmdUb3A6IDEwLFxyXG4gICAgcGFkZGluZ0xlZnQ6IDIsXHJcbiAgICBib3JkZXI6ICdzb2xpZCcsXHJcbiAgICBib3JkZXJXaWR0aDogMSxcclxuICAgIG1hcmdpbkJvdHRvbTogNVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e2Jsb2dTdHlsZX0+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAge2Jsb2cudGl0bGV9IHtibG9nLmF1dGhvcn0gPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT57dmlzaWJsZSA/ICdoaWRlJyA6ICd2aWV3J308L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHt2aXNpYmxlICYmIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPHA+e2Jsb2cudXJsfTwvcD5cclxuICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICB7YmxvZy5saWtlc30gbGlrZXMgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVMaWtlKGJsb2cuaWQpfT5saWtlPC9idXR0b24+XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8cD57YmxvZy51c2VyICYmIGJsb2cudXNlci5uYW1lfTwvcD5cclxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKGJsb2cuaWQpfT5kZWxldGU8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQmxvZyJdLCJmaWxlIjoiRDovR2l0aHViL0tvdWx1L09zYTVSZVRyeUZyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2cuanN4In0=