import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d99eaa26"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=d99eaa26"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({
  createBlog
}) => {
  _s();
  const [newTitle, setNewTitle] = useState("");
  const [newAuthor, setNewAuthor] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const handleTitleChange = ({
    target
  }) => setNewTitle(target.value);
  const handleAuthorChange = ({
    target
  }) => setNewAuthor(target.value);
  const handleUrlChange = ({
    target
  }) => setNewUrl(target.value);
  const addBlog = (event) => {
    event.preventDefault();
    createBlog({
      title: newTitle,
      author: newAuthor,
      url: newUrl
    });
    setNewTitle("");
    setNewAuthor("");
    setNewUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Create a new blog" }, void 0, false, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: addBlog, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "title", children: "Title:" }, void 0, false, {
          fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
          lineNumber: 34,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "Title", id: "title", type: "text", value: newTitle, name: "Title", onChange: handleTitleChange }, void 0, false, {
          fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
          lineNumber: 35,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
        lineNumber: 33,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "author", children: "Author:" }, void 0, false, {
          fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
          lineNumber: 38,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "Author", id: "author", type: "text", value: newAuthor, name: "Author", onChange: handleAuthorChange }, void 0, false, {
          fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
          lineNumber: 39,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
        lineNumber: 37,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "url", children: "URL:" }, void 0, false, {
          fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
          lineNumber: 42,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "URL", id: "url", type: "text", value: newUrl, name: "URL", onChange: handleUrlChange }, void 0, false, {
          fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
          lineNumber: 43,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
        lineNumber: 41,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
        lineNumber: 45,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
      lineNumber: 32,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx",
    lineNumber: 30,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "K8n1d7EVyFnsPPMgmWFF2Yqmsas=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Github/Koulu/Osa5ReTryFrontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCTixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQztBQUFBLEVBQUVDO0FBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJTCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDTSxXQUFXQyxZQUFZLElBQUlQLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNRLFFBQVFDLFNBQVMsSUFBSVQsU0FBUyxFQUFFO0FBRXZDLFFBQU1VLG9CQUFvQkEsQ0FBQztBQUFBLElBQUVDO0FBQUFBLEVBQU8sTUFBTU4sWUFBWU0sT0FBT0MsS0FBSztBQUNsRSxRQUFNQyxxQkFBcUJBLENBQUM7QUFBQSxJQUFFRjtBQUFBQSxFQUFPLE1BQU1KLGFBQWFJLE9BQU9DLEtBQUs7QUFDcEUsUUFBTUUsa0JBQWtCQSxDQUFDO0FBQUEsSUFBRUg7QUFBQUEsRUFBTyxNQUFNRixVQUFVRSxPQUFPQyxLQUFLO0FBRTlELFFBQU1HLFVBQVdDLFdBQVU7QUFDekJBLFVBQU1DLGVBQWU7QUFDckJmLGVBQVc7QUFBQSxNQUNUZ0IsT0FBT2Q7QUFBQUEsTUFDUGUsUUFBUWI7QUFBQUEsTUFDUmMsS0FBS1o7QUFBQUEsSUFDUCxDQUFDO0FBQ0RILGdCQUFZLEVBQUU7QUFDZEUsaUJBQWEsRUFBRTtBQUNmRSxjQUFVLEVBQUU7QUFBQSxFQUNkO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxpQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFCO0FBQUEsSUFDckIsdUJBQUMsVUFBSyxVQUFVTSxTQUNkO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sU0FBUSxTQUFRLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsUUFDN0IsdUJBQUMsV0FDQyxlQUFZLFNBQ1osSUFBRyxTQUNILE1BQUssUUFDTCxPQUFPWCxVQUNQLE1BQUssU0FDTCxVQUFVTSxxQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTThCO0FBQUEsV0FSaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsV0FBTSxTQUFRLFVBQVMsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQSxRQUMvQix1QkFBQyxXQUNDLGVBQVksVUFDWixJQUFHLFVBQ0gsTUFBSyxRQUNMLE9BQU9KLFdBQ1AsTUFBSyxVQUNMLFVBQVVPLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNK0I7QUFBQSxXQVJqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxXQUFNLFNBQVEsT0FBTSxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQ3pCLHVCQUFDLFdBQ0MsZUFBWSxPQUNaLElBQUcsT0FDSCxNQUFLLFFBQ0wsT0FBT0wsUUFDUCxNQUFLLE9BQ0wsVUFBVU0sbUJBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU00QjtBQUFBLFdBUjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxTQWxDOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQTtBQUFBLE9BckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ0E7QUFFSjtBQUFDWCxHQTlES0YsVUFBUTtBQUFBb0IsS0FBUnBCO0FBZ0VOLGVBQWVBO0FBQVEsSUFBQW9CO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkJsb2dGb3JtIiwiY3JlYXRlQmxvZyIsIl9zIiwibmV3VGl0bGUiLCJzZXROZXdUaXRsZSIsIm5ld0F1dGhvciIsInNldE5ld0F1dGhvciIsIm5ld1VybCIsInNldE5ld1VybCIsImhhbmRsZVRpdGxlQ2hhbmdlIiwidGFyZ2V0IiwidmFsdWUiLCJoYW5kbGVBdXRob3JDaGFuZ2UiLCJoYW5kbGVVcmxDaGFuZ2UiLCJhZGRCbG9nIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuXHJcbmNvbnN0IEJsb2dGb3JtID0gKHsgY3JlYXRlQmxvZyB9KSA9PiB7XHJcbiAgY29uc3QgW25ld1RpdGxlLCBzZXROZXdUaXRsZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbbmV3QXV0aG9yLCBzZXROZXdBdXRob3JdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW25ld1VybCwgc2V0TmV3VXJsXSA9IHVzZVN0YXRlKCcnKVxyXG5cclxuICBjb25zdCBoYW5kbGVUaXRsZUNoYW5nZSA9ICh7IHRhcmdldCB9KSA9PiBzZXROZXdUaXRsZSh0YXJnZXQudmFsdWUpXHJcbiAgY29uc3QgaGFuZGxlQXV0aG9yQ2hhbmdlID0gKHsgdGFyZ2V0IH0pID0+IHNldE5ld0F1dGhvcih0YXJnZXQudmFsdWUpXHJcbiAgY29uc3QgaGFuZGxlVXJsQ2hhbmdlID0gKHsgdGFyZ2V0IH0pID0+IHNldE5ld1VybCh0YXJnZXQudmFsdWUpXHJcblxyXG4gIGNvbnN0IGFkZEJsb2cgPSAoZXZlbnQpID0+IHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgIGNyZWF0ZUJsb2coe1xyXG4gICAgICB0aXRsZTogbmV3VGl0bGUsXHJcbiAgICAgIGF1dGhvcjogbmV3QXV0aG9yLFxyXG4gICAgICB1cmw6IG5ld1VybFxyXG4gICAgfSlcclxuICAgIHNldE5ld1RpdGxlKCcnKVxyXG4gICAgc2V0TmV3QXV0aG9yKCcnKVxyXG4gICAgc2V0TmV3VXJsKCcnKVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxoMj5DcmVhdGUgYSBuZXcgYmxvZzwvaDI+XHJcbiAgICAgIDxmb3JtIG9uU3VibWl0PXthZGRCbG9nfT5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJ0aXRsZVwiPlRpdGxlOjwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J1RpdGxlJ1xyXG4gICAgICAgICAgICBpZD1cInRpdGxlXCJcclxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICB2YWx1ZT17bmV3VGl0bGV9XHJcbiAgICAgICAgICAgIG5hbWU9XCJUaXRsZVwiXHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVUaXRsZUNoYW5nZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiYXV0aG9yXCI+QXV0aG9yOjwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J0F1dGhvcidcclxuICAgICAgICAgICAgaWQ9XCJhdXRob3JcIlxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtuZXdBdXRob3J9XHJcbiAgICAgICAgICAgIG5hbWU9XCJBdXRob3JcIlxyXG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQXV0aG9yQ2hhbmdlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJ1cmxcIj5VUkw6PC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0nVVJMJ1xyXG4gICAgICAgICAgICBpZD1cInVybFwiXHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgdmFsdWU9e25ld1VybH1cclxuICAgICAgICAgICAgbmFtZT1cIlVSTFwiXHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVVcmxDaGFuZ2V9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmNyZWF0ZTwvYnV0dG9uPlxyXG4gICAgICA8L2Zvcm0+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJsb2dGb3JtIl0sImZpbGUiOiJEOi9HaXRodWIvS291bHUvT3NhNVJlVHJ5RnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZ0Zvcm0uanN4In0=