import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d99eaa26"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=d99eaa26"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
const Blog = ({
  blog,
  handleLike,
  handleDelete,
  currentUser
}) => {
  _s();
  const [visible, setVisible] = useState(false);
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const showDeleteButton = currentUser && blog.user && currentUser.username === blog.user.username;
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: visible ? "hide" : "view" }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
        lineNumber: 24,
        columnNumber: 36
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    visible && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { children: blog.url }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
        lineNumber: 27,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        blog.likes,
        " likes ",
        /* @__PURE__ */ jsxDEV("button", { onClick: () => handleLike(blog.id), children: "like" }, void 0, false, {
          fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
          lineNumber: 29,
          columnNumber: 32
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
        lineNumber: 28,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: blog.user && blog.user.name }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
        lineNumber: 31,
        columnNumber: 11
      }, this),
      showDeleteButton && /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDelete(blog.id), children: "delete" }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
        lineNumber: 32,
        columnNumber: 32
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
      lineNumber: 26,
      columnNumber: 19
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
};
_s(Blog, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Github/Koulu/Osa5ReTryFrontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JtQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0Qm5DLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUVoQyxNQUFNQyxPQUFPQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBWUM7QUFBQUEsRUFBY0M7QUFBWSxNQUFNO0FBQUFDLEtBQUE7QUFDaEUsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlSLFNBQVMsS0FBSztBQUU1QyxRQUFNUyxtQkFBbUJBLE1BQU07QUFDN0JELGVBQVcsQ0FBQ0QsT0FBTztBQUFBLEVBQ3JCO0FBRUEsUUFBTUcsWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLEVBQ2hCO0FBRUEsUUFBTUMsbUJBQW1CWCxlQUFlSCxLQUFLZSxRQUFRWixZQUFZYSxhQUFhaEIsS0FBS2UsS0FBS0M7QUFFeEYsU0FDRSx1QkFBQyxTQUFJLE9BQU9SLFdBQ1Y7QUFBQSwyQkFBQyxTQUNFUjtBQUFBQSxXQUFLaUI7QUFBQUEsTUFBTTtBQUFBLE1BQUVqQixLQUFLa0I7QUFBQUEsTUFBTztBQUFBLE1BQUMsdUJBQUMsWUFBTyxTQUFTWCxrQkFBbUJGLG9CQUFVLFNBQVMsVUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLFNBRDNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0NBLFdBQ0MsdUJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUdMLGVBQUttQixPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYTtBQUFBLE1BQ2IsdUJBQUMsT0FDRW5CO0FBQUFBLGFBQUtvQjtBQUFBQSxRQUFNO0FBQUEsUUFBTyx1QkFBQyxZQUFPLFNBQVMsTUFBTW5CLFdBQVdELEtBQUtxQixFQUFFLEdBQUcsb0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQSxXQURyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUdyQixlQUFLZSxRQUFRZixLQUFLZSxLQUFLTyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDO0FBQUEsTUFDL0JSLG9CQUFvQix1QkFBQyxZQUFPLFNBQVMsTUFBTVosYUFBYUYsS0FBS3FCLEVBQUUsR0FBRyxzQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRDtBQUFBLFNBTjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWNBO0FBRUo7QUFBQ2pCLEdBbENLTCxNQUFJO0FBQUF3QixLQUFKeEI7QUFvQ04sZUFBZUE7QUFBSSxJQUFBd0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJCbG9nIiwiYmxvZyIsImhhbmRsZUxpa2UiLCJoYW5kbGVEZWxldGUiLCJjdXJyZW50VXNlciIsIl9zIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJ0b2dnbGVWaXNpYmlsaXR5IiwiYmxvZ1N0eWxlIiwicGFkZGluZ1RvcCIsInBhZGRpbmdMZWZ0IiwiYm9yZGVyIiwiYm9yZGVyV2lkdGgiLCJtYXJnaW5Cb3R0b20iLCJzaG93RGVsZXRlQnV0dG9uIiwidXNlciIsInVzZXJuYW1lIiwidGl0bGUiLCJhdXRob3IiLCJ1cmwiLCJsaWtlcyIsImlkIiwibmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcblxyXG5jb25zdCBCbG9nID0gKHsgYmxvZywgaGFuZGxlTGlrZSwgaGFuZGxlRGVsZXRlLCBjdXJyZW50VXNlciB9KSA9PiB7XHJcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiB7XHJcbiAgICBzZXRWaXNpYmxlKCF2aXNpYmxlKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xyXG4gICAgcGFkZGluZ1RvcDogMTAsXHJcbiAgICBwYWRkaW5nTGVmdDogMixcclxuICAgIGJvcmRlcjogJ3NvbGlkJyxcclxuICAgIGJvcmRlcldpZHRoOiAxLFxyXG4gICAgbWFyZ2luQm90dG9tOiA1XHJcbiAgfVxyXG5cclxuICBjb25zdCBzaG93RGVsZXRlQnV0dG9uID0gY3VycmVudFVzZXIgJiYgYmxvZy51c2VyICYmIGN1cnJlbnRVc2VyLnVzZXJuYW1lID09PSBibG9nLnVzZXIudXNlcm5hbWVcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e2Jsb2dTdHlsZX0+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAge2Jsb2cudGl0bGV9IHtibG9nLmF1dGhvcn0gPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT57dmlzaWJsZSA/ICdoaWRlJyA6ICd2aWV3J308L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHt2aXNpYmxlICYmIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPHA+e2Jsb2cudXJsfTwvcD5cclxuICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICB7YmxvZy5saWtlc30gbGlrZXMgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVMaWtlKGJsb2cuaWQpfT5saWtlPC9idXR0b24+XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8cD57YmxvZy51c2VyICYmIGJsb2cudXNlci5uYW1lfTwvcD5cclxuICAgICAgICAgIHtzaG93RGVsZXRlQnV0dG9uICYmIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKGJsb2cuaWQpfT5kZWxldGU8L2J1dHRvbj59XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJsb2ciXSwiZmlsZSI6IkQ6L0dpdGh1Yi9Lb3VsdS9Pc2E1UmVUcnlGcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9