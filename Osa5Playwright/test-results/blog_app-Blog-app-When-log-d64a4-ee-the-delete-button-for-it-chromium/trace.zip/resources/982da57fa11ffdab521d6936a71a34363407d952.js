import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d99eaa26"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=d99eaa26"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
const LoginForm = ({
  handleLogin
}) => {
  _s();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };
  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    handleLogin({
      username,
      password
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Login" }, void 0, false, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("label", { children: [
        "Username:",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", type: "text", value: username, onChange: handleUsernameChange }, void 0, false, {
          fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
          lineNumber: 28,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
        lineNumber: 26,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
        lineNumber: 25,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("label", { children: [
        "Password:",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "password", type: "password", value: password, onChange: handlePasswordChange }, void 0, false, {
          fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
          lineNumber: 34,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
        lineNumber: 32,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Login" }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
        lineNumber: 38,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
      lineNumber: 24,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
};
_s(LoginForm, "wuQOK7xaXdVz4RMrZQhWbI751Oc=");
_c = LoginForm;
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Github/Koulu/Osa5ReTryFrontend/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCTixPQUFPQSxTQUFTQyxnQkFBZ0I7QUFFaEMsTUFBTUMsWUFBWUEsQ0FBQztBQUFBLEVBQUVDO0FBQVksTUFBTTtBQUFBQyxLQUFBO0FBQ3JDLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJTCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDTSxVQUFVQyxXQUFXLElBQUlQLFNBQVMsRUFBRTtBQUUzQyxRQUFNUSx1QkFBd0JDLFdBQVU7QUFDdENKLGdCQUFZSSxNQUFNQyxPQUFPQyxLQUFLO0FBQUEsRUFDaEM7QUFFQSxRQUFNQyx1QkFBd0JILFdBQVU7QUFDdENGLGdCQUFZRSxNQUFNQyxPQUFPQyxLQUFLO0FBQUEsRUFDaEM7QUFFQSxRQUFNRSxlQUFlLE9BQU9KLFVBQVU7QUFDcENBLFVBQU1LLGVBQWU7QUFDckJaLGdCQUFZO0FBQUEsTUFBRUU7QUFBQUEsTUFBVUU7QUFBQUEsSUFBUyxDQUFDO0FBQUEsRUFDcEM7QUFFQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsVUFBSyxVQUFVTyxjQUNkO0FBQUEsNkJBQUMsU0FDQyxpQ0FBQyxXQUFNO0FBQUE7QUFBQSxRQUVMLHVCQUFDLFdBQ0MsZUFBWSxZQUNaLE1BQUssUUFDTCxPQUFPVCxVQUNQLFVBQVVJLHdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJaUM7QUFBQSxXQU5uQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0MsaUNBQUMsV0FBTTtBQUFBO0FBQUEsUUFFTCx1QkFBQyxXQUNDLGVBQVksWUFDWixNQUFLLFlBQ0wsT0FBT0YsVUFDUCxVQUFVTSx3QkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSWlDO0FBQUEsV0FObkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxTQUNDLGlDQUFDLFlBQU8sTUFBSyxVQUFTLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJCLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxPQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkJBO0FBRUo7QUFBQ1QsR0FqREtGLFdBQVM7QUFBQWMsS0FBVGQ7QUFtRE4sZUFBZUE7QUFBUyxJQUFBYztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsIkxvZ2luRm9ybSIsImhhbmRsZUxvZ2luIiwiX3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImhhbmRsZVVzZXJuYW1lQ2hhbmdlIiwiZXZlbnQiLCJ0YXJnZXQiLCJ2YWx1ZSIsImhhbmRsZVBhc3N3b3JkQ2hhbmdlIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvZ2luRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcblxyXG5jb25zdCBMb2dpbkZvcm0gPSAoeyBoYW5kbGVMb2dpbiB9KSA9PiB7XHJcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxyXG5cclxuICBjb25zdCBoYW5kbGVVc2VybmFtZUNoYW5nZSA9IChldmVudCkgPT4ge1xyXG4gICAgc2V0VXNlcm5hbWUoZXZlbnQudGFyZ2V0LnZhbHVlKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlUGFzc3dvcmRDaGFuZ2UgPSAoZXZlbnQpID0+IHtcclxuICAgIHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgaGFuZGxlTG9naW4oeyB1c2VybmFtZSwgcGFzc3dvcmQgfSlcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aDI+TG9naW48L2gyPlxyXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsPlxyXG4gICAgICAgICAgICBVc2VybmFtZTpcclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3VzZXJuYW1lJ1xyXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVVzZXJuYW1lQ2hhbmdlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsPlxyXG4gICAgICAgICAgICBQYXNzd29yZDpcclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3Bhc3N3b3JkJ1xyXG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXNzd29yZENoYW5nZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPkxvZ2luPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTG9naW5Gb3JtIl0sImZpbGUiOiJEOi9HaXRodWIvS291bHUvT3NhNVJlVHJ5RnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTG9naW5Gb3JtLmpzeCJ9