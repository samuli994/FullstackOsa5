import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d99eaa26"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=d99eaa26"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Blog from "/src/components/Blog.jsx?t=1719315854344";
import BlogForm from "/src/components/BlogForm.jsx?t=1719314687908";
import LoginForm from "/src/components/LoginForm.jsx?t=1719312177884";
import Notification from "/src/components/Notification.jsx";
import loginService from "/src/services/login.js";
import blogService from "/src/services/blogs.js";
import Togglable from "/src/components/Togglable.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [user, setUser] = useState(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [notificationMessage, setNotificationMessage] = useState(null);
  const [notificationType, setNotificationType] = useState("");
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    blogService.getAll().then((initialBlogs) => {
      initialBlogs.sort((a, b) => b.likes - a.likes);
      setBlogs(initialBlogs);
    });
  }, []);
  const handleLogin = async (credentials) => {
    try {
      const user2 = await loginService.login(credentials);
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      console.error("Login failed:", exception);
      showNotification("Wrong username or password", "error");
    }
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogappUser");
    setUser(null);
  };
  const addBlog = async (blogObject) => {
    try {
      const newBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat(newBlog));
      showNotification(`A new blog ${newBlog.title} by ${newBlog.author} added`, "success");
    } catch (exception) {
      showNotification("Error adding blog", "error");
    }
  };
  const handleLike = async (id) => {
    const blogToLike = blogs.find((blog) => blog.id === id);
    const updatedBlog = {
      ...blogToLike,
      likes: blogToLike.likes + 1
    };
    try {
      const returnedBlog = await blogService.update(id, updatedBlog);
      setBlogs(blogs.map((blog) => blog.id !== id ? blog : returnedBlog));
      showNotification(`Liked ${returnedBlog.title}`, "success");
    } catch (exception) {
      showNotification("Error liking blog", "error");
    }
  };
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this blog?")) {
      try {
        await blogService.remove(id);
        setBlogs(blogs.filter((blog) => blog.id !== id));
        showNotification("Blog removed successfully", "success");
      } catch (error) {
        showNotification("Error removing blog", "error");
      }
    }
  };
  const showNotification = (message, type) => {
    setNotificationMessage(message);
    setNotificationType(type);
    setTimeout(() => {
      setNotificationMessage(null);
      setNotificationType("");
    }, 5e3);
  };
  if (user === null) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV(Notification, { message: notificationMessage, type: notificationType }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
        lineNumber: 93,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(LoginForm, { handleLogin }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
        lineNumber: 94,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
      lineNumber: 92,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Blogs" }, void 0, false, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
      lineNumber: 98,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: notificationMessage, type: notificationType }, void 0, false, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
      lineNumber: 99,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      user.name,
      " logged in ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
        fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
        lineNumber: 100,
        columnNumber: 32
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
      lineNumber: 100,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "new blog", children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
      lineNumber: 102,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { children: "Existing blogs" }, void 0, false, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
      lineNumber: 105,
      columnNumber: 7
    }, this),
    blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, handleLike, handleDelete, currentUser: user }, blog.id, false, {
      fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
      lineNumber: 106,
      columnNumber: 26
    }, this))
  ] }, void 0, true, {
    fileName: "D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx",
    lineNumber: 97,
    columnNumber: 10
  }, this);
};
_s(App, "3DwgWSTjEPKywuGB3lNrmPQ/GSw=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Github/Koulu/Osa5ReTryFrontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUdROzs7Ozs7Ozs7Ozs7Ozs7OztBQW5HUixPQUFPQSxTQUFTQyxVQUFVQyxpQkFBaUI7QUFDM0MsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxNQUFNQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEIsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlaLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNhLE1BQU1DLE9BQU8sSUFBSWQsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ2UsVUFBVUMsV0FBVyxJQUFJaEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2lCLFVBQVVDLFdBQVcsSUFBSWxCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNtQixxQkFBcUJDLHNCQUFzQixJQUFJcEIsU0FBUyxJQUFJO0FBQ25FLFFBQU0sQ0FBQ3FCLGtCQUFrQkMsbUJBQW1CLElBQUl0QixTQUFTLEVBQUU7QUFFM0RDLFlBQVUsTUFBTTtBQUNkLFVBQU1zQixpQkFBaUJDLE9BQU9DLGFBQWFDLFFBQVEsbUJBQW1CO0FBQ3RFLFFBQUlILGdCQUFnQjtBQUNsQixZQUFNVixRQUFPYyxLQUFLQyxNQUFNTCxjQUFjO0FBQ3RDVCxjQUFRRCxLQUFJO0FBQ1pOLGtCQUFZc0IsU0FBU2hCLE1BQUtpQixLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMN0IsWUFBVSxNQUFNO0FBQ2RNLGdCQUFZd0IsT0FBTyxFQUFFQyxLQUFLQyxrQkFBZ0I7QUFDeENBLG1CQUFhQyxLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVDLFFBQVFGLEVBQUVFLEtBQUs7QUFDN0N6QixlQUFTcUIsWUFBWTtBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILEdBQUcsRUFBRTtBQUVMLFFBQU1LLGNBQWMsT0FBT0MsZ0JBQWdCO0FBQ3pDLFFBQUk7QUFDRixZQUFNMUIsUUFBTyxNQUFNUCxhQUFha0MsTUFBTUQsV0FBVztBQUNqRGYsYUFBT0MsYUFBYWdCLFFBQVEscUJBQXFCZCxLQUFLZSxVQUFVN0IsS0FBSSxDQUFDO0FBQ3JFTixrQkFBWXNCLFNBQVNoQixNQUFLaUIsS0FBSztBQUMvQmhCLGNBQVFELEtBQUk7QUFDWkcsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQUEsSUFDaEIsU0FBU3lCLFdBQVc7QUFDbEJDLGNBQVFDLE1BQU0saUJBQWlCRixTQUFTO0FBQ3hDRyx1QkFBaUIsOEJBQThCLE9BQU87QUFBQSxJQUN4RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxlQUFlQSxNQUFNO0FBQ3pCdkIsV0FBT0MsYUFBYXVCLFdBQVcsbUJBQW1CO0FBQ2xEbEMsWUFBUSxJQUFJO0FBQUEsRUFDZDtBQUdBLFFBQU1tQyxVQUFVLE9BQU9DLGVBQWU7QUFDcEMsUUFBSTtBQUNGLFlBQU1DLFVBQVUsTUFBTTVDLFlBQVk2QyxPQUFPRixVQUFVO0FBQ25EdEMsZUFBU0QsTUFBTTBDLE9BQU9GLE9BQU8sQ0FBQztBQUM5QkwsdUJBQWtCLGNBQWFLLFFBQVFHLEtBQU0sT0FBTUgsUUFBUUksTUFBTyxVQUFTLFNBQVM7QUFBQSxJQUN0RixTQUFTWixXQUFXO0FBQ2xCRyx1QkFBaUIscUJBQXFCLE9BQU87QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFFQSxRQUFNVSxhQUFhLE9BQU9DLE9BQU87QUFDL0IsVUFBTUMsYUFBYS9DLE1BQU1nRCxLQUFLQyxVQUFRQSxLQUFLSCxPQUFPQSxFQUFFO0FBQ3BELFVBQU1JLGNBQWM7QUFBQSxNQUFFLEdBQUdIO0FBQUFBLE1BQVlyQixPQUFPcUIsV0FBV3JCLFFBQVE7QUFBQSxJQUFFO0FBQ2pFLFFBQUk7QUFDRixZQUFNeUIsZUFBZSxNQUFNdkQsWUFBWXdELE9BQU9OLElBQUlJLFdBQVc7QUFDN0RqRCxlQUFTRCxNQUFNcUQsSUFBSUosVUFBUUEsS0FBS0gsT0FBT0EsS0FBS0csT0FBT0UsWUFBWSxDQUFDO0FBQ2hFaEIsdUJBQWtCLFNBQVFnQixhQUFhUixLQUFNLElBQUcsU0FBUztBQUFBLElBQzNELFNBQVNYLFdBQVc7QUFDbEJHLHVCQUFpQixxQkFBcUIsT0FBTztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUVBLFFBQU1tQixlQUFlLE9BQU9SLE9BQU87QUFDakMsUUFBSWpDLE9BQU8wQyxRQUFRLDRDQUE0QyxHQUFHO0FBQ2hFLFVBQUk7QUFDRixjQUFNM0QsWUFBWTRELE9BQU9WLEVBQUU7QUFDM0I3QyxpQkFBU0QsTUFBTXlELE9BQU9SLFVBQVFBLEtBQUtILE9BQU9BLEVBQUUsQ0FBQztBQUM3Q1gseUJBQWlCLDZCQUE2QixTQUFTO0FBQUEsTUFDekQsU0FBU0QsT0FBTztBQUNkQyx5QkFBaUIsdUJBQXVCLE9BQU87QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTUEsbUJBQW1CQSxDQUFDdUIsU0FBU0MsU0FBUztBQUMxQ2xELDJCQUF1QmlELE9BQU87QUFDOUIvQyx3QkFBb0JnRCxJQUFJO0FBQ3hCQyxlQUFXLE1BQU07QUFDZm5ELDZCQUF1QixJQUFJO0FBQzNCRSwwQkFBb0IsRUFBRTtBQUFBLElBQ3hCLEdBQUcsR0FBSTtBQUFBLEVBQ1Q7QUFFQSxNQUFJVCxTQUFTLE1BQU07QUFDakIsV0FDRSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsZ0JBQWEsU0FBU00scUJBQXFCLE1BQU1FLG9CQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FO0FBQUEsTUFDbkUsdUJBQUMsYUFBVSxlQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxTQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxFQUVKO0FBR0EsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLGdCQUFhLFNBQVNGLHFCQUFxQixNQUFNRSxvQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRTtBQUFBLElBQ25FLHVCQUFDLE9BQUdSO0FBQUFBLFdBQUsyRDtBQUFBQSxNQUFLO0FBQUEsTUFBVyx1QkFBQyxZQUFPLFNBQVN6QixjQUFjLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsU0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RTtBQUFBLElBQ3ZFLHVCQUFDLGFBQVUsYUFBWSxZQUNyQixpQ0FBQyxZQUFTLFlBQVlFLFdBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEIsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxRQUFHLDhCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0I7QUFBQSxJQUNqQnRDLE1BQU1xRCxJQUFJSixVQUNULHVCQUFDLFFBRUMsTUFDQSxZQUNBLGNBQ0EsYUFBYS9DLFFBSlIrQyxLQUFLSCxJQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLb0IsQ0FFdEI7QUFBQSxPQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBO0FBRUo7QUFBQy9DLEdBdEhLRCxLQUFHO0FBQUFnRSxLQUFIaEU7QUF1SE4sZUFBZUE7QUFBRyxJQUFBZ0U7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJCbG9nIiwiQmxvZ0Zvcm0iLCJMb2dpbkZvcm0iLCJOb3RpZmljYXRpb24iLCJsb2dpblNlcnZpY2UiLCJibG9nU2VydmljZSIsIlRvZ2dsYWJsZSIsIkFwcCIsIl9zIiwiYmxvZ3MiLCJzZXRCbG9ncyIsInVzZXIiLCJzZXRVc2VyIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJub3RpZmljYXRpb25NZXNzYWdlIiwic2V0Tm90aWZpY2F0aW9uTWVzc2FnZSIsIm5vdGlmaWNhdGlvblR5cGUiLCJzZXROb3RpZmljYXRpb25UeXBlIiwibG9nZ2VkVXNlckpTT04iLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsImdldEFsbCIsInRoZW4iLCJpbml0aWFsQmxvZ3MiLCJzb3J0IiwiYSIsImIiLCJsaWtlcyIsImhhbmRsZUxvZ2luIiwiY3JlZGVudGlhbHMiLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJleGNlcHRpb24iLCJjb25zb2xlIiwiZXJyb3IiLCJzaG93Tm90aWZpY2F0aW9uIiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsImFkZEJsb2ciLCJibG9nT2JqZWN0IiwibmV3QmxvZyIsImNyZWF0ZSIsImNvbmNhdCIsInRpdGxlIiwiYXV0aG9yIiwiaGFuZGxlTGlrZSIsImlkIiwiYmxvZ1RvTGlrZSIsImZpbmQiLCJibG9nIiwidXBkYXRlZEJsb2ciLCJyZXR1cm5lZEJsb2ciLCJ1cGRhdGUiLCJtYXAiLCJoYW5kbGVEZWxldGUiLCJjb25maXJtIiwicmVtb3ZlIiwiZmlsdGVyIiwibWVzc2FnZSIsInR5cGUiLCJzZXRUaW1lb3V0IiwibmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcclxuaW1wb3J0IEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybSdcclxuaW1wb3J0IExvZ2luRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvTG9naW5Gb3JtJ1xyXG5pbXBvcnQgTm90aWZpY2F0aW9uIGZyb20gJy4vY29tcG9uZW50cy9Ob3RpZmljYXRpb24nXHJcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcclxuaW1wb3J0IGJsb2dTZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvYmxvZ3MnXHJcbmltcG9ydCBUb2dnbGFibGUgZnJvbSAnLi9jb21wb25lbnRzL1RvZ2dsYWJsZSdcclxuXHJcbmNvbnN0IEFwcCA9ICgpID0+IHtcclxuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxyXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtub3RpZmljYXRpb25NZXNzYWdlLCBzZXROb3RpZmljYXRpb25NZXNzYWdlXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgY29uc3QgW25vdGlmaWNhdGlvblR5cGUsIHNldE5vdGlmaWNhdGlvblR5cGVdID0gdXNlU3RhdGUoJycpXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxyXG4gICAgaWYgKGxvZ2dlZFVzZXJKU09OKSB7XHJcbiAgICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvZ2dlZFVzZXJKU09OKVxyXG4gICAgICBzZXRVc2VyKHVzZXIpXHJcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXHJcbiAgICB9XHJcbiAgfSwgW10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGluaXRpYWxCbG9ncyA9PiB7XHJcbiAgICAgIGluaXRpYWxCbG9ncy5zb3J0KChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlcylcclxuICAgICAgc2V0QmxvZ3MoaW5pdGlhbEJsb2dzKVxyXG4gICAgfSlcclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoY3JlZGVudGlhbHMpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBsb2dpblNlcnZpY2UubG9naW4oY3JlZGVudGlhbHMpXHJcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKSlcclxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcclxuICAgICAgc2V0VXNlcih1c2VyKVxyXG4gICAgICBzZXRVc2VybmFtZSgnJylcclxuICAgICAgc2V0UGFzc3dvcmQoJycpXHJcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcclxuICAgICAgY29uc29sZS5lcnJvcignTG9naW4gZmFpbGVkOicsIGV4Y2VwdGlvbilcclxuICAgICAgc2hvd05vdGlmaWNhdGlvbignV3JvbmcgdXNlcm5hbWUgb3IgcGFzc3dvcmQnLCAnZXJyb3InKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRCbG9nYXBwVXNlcicpXHJcbiAgICBzZXRVc2VyKG51bGwpXHJcbiAgfVxyXG5cclxuXHJcbiAgY29uc3QgYWRkQmxvZyA9IGFzeW5jIChibG9nT2JqZWN0KSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBuZXdCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UuY3JlYXRlKGJsb2dPYmplY3QpXHJcbiAgICAgIHNldEJsb2dzKGJsb2dzLmNvbmNhdChuZXdCbG9nKSlcclxuICAgICAgc2hvd05vdGlmaWNhdGlvbihgQSBuZXcgYmxvZyAke25ld0Jsb2cudGl0bGV9IGJ5ICR7bmV3QmxvZy5hdXRob3J9IGFkZGVkYCwgJ3N1Y2Nlc3MnKVxyXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XHJcbiAgICAgIHNob3dOb3RpZmljYXRpb24oJ0Vycm9yIGFkZGluZyBibG9nJywgJ2Vycm9yJylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZUxpa2UgPSBhc3luYyAoaWQpID0+IHtcclxuICAgIGNvbnN0IGJsb2dUb0xpa2UgPSBibG9ncy5maW5kKGJsb2cgPT4gYmxvZy5pZCA9PT0gaWQpXHJcbiAgICBjb25zdCB1cGRhdGVkQmxvZyA9IHsgLi4uYmxvZ1RvTGlrZSwgbGlrZXM6IGJsb2dUb0xpa2UubGlrZXMgKyAxIH1cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJldHVybmVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLnVwZGF0ZShpZCwgdXBkYXRlZEJsb2cpXHJcbiAgICAgIHNldEJsb2dzKGJsb2dzLm1hcChibG9nID0+IGJsb2cuaWQgIT09IGlkID8gYmxvZyA6IHJldHVybmVkQmxvZykpXHJcbiAgICAgIHNob3dOb3RpZmljYXRpb24oYExpa2VkICR7cmV0dXJuZWRCbG9nLnRpdGxlfWAsICdzdWNjZXNzJylcclxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xyXG4gICAgICBzaG93Tm90aWZpY2F0aW9uKCdFcnJvciBsaWtpbmcgYmxvZycsICdlcnJvcicpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGUgPSBhc3luYyAoaWQpID0+IHtcclxuICAgIGlmICh3aW5kb3cuY29uZmlybSgnQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIGJsb2c/JykpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBibG9nU2VydmljZS5yZW1vdmUoaWQpXHJcbiAgICAgICAgc2V0QmxvZ3MoYmxvZ3MuZmlsdGVyKGJsb2cgPT4gYmxvZy5pZCAhPT0gaWQpKVxyXG4gICAgICAgIHNob3dOb3RpZmljYXRpb24oJ0Jsb2cgcmVtb3ZlZCBzdWNjZXNzZnVsbHknLCAnc3VjY2VzcycpXHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgc2hvd05vdGlmaWNhdGlvbignRXJyb3IgcmVtb3ZpbmcgYmxvZycsICdlcnJvcicpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IHNob3dOb3RpZmljYXRpb24gPSAobWVzc2FnZSwgdHlwZSkgPT4ge1xyXG4gICAgc2V0Tm90aWZpY2F0aW9uTWVzc2FnZShtZXNzYWdlKVxyXG4gICAgc2V0Tm90aWZpY2F0aW9uVHlwZSh0eXBlKVxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIHNldE5vdGlmaWNhdGlvbk1lc3NhZ2UobnVsbClcclxuICAgICAgc2V0Tm90aWZpY2F0aW9uVHlwZSgnJylcclxuICAgIH0sIDUwMDApXHJcbiAgfVxyXG5cclxuICBpZiAodXNlciA9PT0gbnVsbCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuICAgICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e25vdGlmaWNhdGlvbk1lc3NhZ2V9IHR5cGU9e25vdGlmaWNhdGlvblR5cGV9IC8+XHJcbiAgICAgICAgPExvZ2luRm9ybSBoYW5kbGVMb2dpbj17aGFuZGxlTG9naW59IC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH1cclxuXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aDI+QmxvZ3M8L2gyPlxyXG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e25vdGlmaWNhdGlvbk1lc3NhZ2V9IHR5cGU9e25vdGlmaWNhdGlvblR5cGV9IC8+XHJcbiAgICAgIDxwPnt1c2VyLm5hbWV9IGxvZ2dlZCBpbiA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH0+bG9nb3V0PC9idXR0b24+PC9wPlxyXG4gICAgICA8VG9nZ2xhYmxlIGJ1dHRvbkxhYmVsPVwibmV3IGJsb2dcIj5cclxuICAgICAgICA8QmxvZ0Zvcm0gY3JlYXRlQmxvZz17YWRkQmxvZ30gLz5cclxuICAgICAgPC9Ub2dnbGFibGU+XHJcblxyXG4gICAgICA8aDI+RXhpc3RpbmcgYmxvZ3M8L2gyPlxyXG4gICAgICB7YmxvZ3MubWFwKGJsb2cgPT5cclxuICAgICAgICA8QmxvZ1xyXG4gICAgICAgICAga2V5PXtibG9nLmlkfVxyXG4gICAgICAgICAgYmxvZz17YmxvZ31cclxuICAgICAgICAgIGhhbmRsZUxpa2U9e2hhbmRsZUxpa2V9XHJcbiAgICAgICAgICBoYW5kbGVEZWxldGU9e2hhbmRsZURlbGV0ZX1cclxuICAgICAgICAgIGN1cnJlbnRVc2VyPXt1c2VyfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgQXBwIl0sImZpbGUiOiJEOi9HaXRodWIvS291bHUvT3NhNVJlVHJ5RnJvbnRlbmQvc3JjL0FwcC5qc3gifQ==